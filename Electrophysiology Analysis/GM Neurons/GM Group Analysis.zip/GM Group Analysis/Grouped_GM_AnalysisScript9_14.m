
% Analysis 9/14 Grouped GM Analysis

c = colormap(jet);
c_vect = c([1:4:64],:)

%% SUMMATION ANALYSIS

% compare peaks of CP and CF directions for each branch:
figure %all, uncomment top lines; remove outlier in bottom two lines
subplot(2,3,1)
plot([-6 0], [-6 0], 'k-', 'LineWidth', 2); hold on; box off
scatter(Peak_OUT, Peak_IN, 50, c_vect(2,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5);
xlabel('Peak Amplitude OUT (mV)')
ylabel('Peak Amplitude IN (mV)')
xlim([-5 0]); ylim([-5 0])

% compare peaks of CP and CF directions for each branch:
subplot(2,3,2)
plot([-6 0], [-6 0], 'k-', 'LineWidth', 2); hold on; box off
scatter(Int_OUT, Int_IN, 50, c_vect(2,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); box off
xlabel('Integral OUT (mV*s)')
ylabel('Integral IN (mV*s)')
xlim([-5 0]); ylim([-5 0])

% PLOT WITH RMSE
% calculate RMSE for real data vs. identity line
%simulated ID line for data x points of data: 
simulated_data =  [Int_OUT Int_OUT]
real_data = [Int_OUT Int_IN]
RMSerror=sqrt( sum(sum((simulated_data - real_data).^2 )) /(12*2))

subplot(2,3,3) %all, uncomment top lines; remove outlier in bottom two lines
plot([-8 0], [-8 0], 'k-'); hold on
plot([-8 0]+RMSerror, [-8 0], 'g-')
plot([-8 0]-RMSerror, [-8 0], 'g-')
scatter(Int_OUT, Int_IN, 50, c_vect(2,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5);
xlabel('Integral OUT (mV*s)')
ylabel('Integral IN (mV*s)')
text(-2.5, -6, ['RMSE = ' num2str([RMSerror])])
text(-2.5, -6.5, ['n = ' num2str(length(real_data))])
ylim([-5 0]); xlim([-5 0]); box off
%legend('Identity Line', '+ RMSE', '- RMSE ', 'Real data', 'Location' , 'southeastoutside')

% Color by cell 
subplot(2,3,4)
plot([-6 0], [-6 0], 'k-', 'LineWidth', 2); hold on; box off
scatter(Peak_OUT(1:2), Peak_IN(1:2), 50, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Peak_OUT(3:7), Peak_IN(3:7), 50, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Peak_OUT(8:13), Peak_IN(8:13), 50, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Peak_OUT(14:18), Peak_IN(14:18), 50, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Peak_OUT(19:22), Peak_IN(19:22), 50, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
xlabel('Peak Amplitude OUT (mV)')
ylabel('Peak Amplitude IN (mV)')
xlim([-5 0]); ylim([-5 0])

subplot(2,3,5)%all, uncomment top lines; remove outlier in bottom two lines
scatter(Int_OUT(1:2), Int_IN(1:2), 50, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on; box off
scatter(Int_OUT(3:7), Int_IN(3:7), 50, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Int_OUT(8:13), Int_IN(8:13), 50, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Int_OUT(14:18), Int_IN(14:18), 50, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
scatter(Int_OUT(19:22), Int_IN(19:22), 50, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5)
plot([-6 0], [-6 0], 'k-', 'LineWidth', 2); 
xlabel('Integral OUT (mV*s)')
ylabel('Integral IN (mV*s)')
xlim([-5 0]); ylim([-5 0])
legend('GM 33', 'GM 46', 'GM 49', 'GM 50', 'GM 51', 'Location', 'southeast')



%% RESPONSE MAGNITUDE ANALYSIS

%Plot Max Resp Amplitude as a function of distance

figure
subplot(6,1,1)
for i = 1:2
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:))),30, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,2)
for i = 3:7
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:))),30, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,3)
for i = 8:13
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:))),30, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,4)
for i = 14:18
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:))),30, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,5)
for i = 19:22
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:))),30, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 1:5         %format all plots
    subplot(6,1,i)
    box off
    ylim([-2 0])
    xlim([0 1200])
    ylabel('Resp (mV)')
end


% everything, normalized to max response within neuron 
subplot(6,1,6)
for i = 1:2
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:)))./-min(MaxPeak(i,:)),30, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 3:7
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:)))./-min(MaxPeak(i,:)),30, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 8:13
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:)))./-min(MaxPeak(i,:)),30, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 14:18
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:)))./-min(MaxPeak(i,:)),30, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 19:22
    scatter(Dist(i,~isnan(MaxPeak(i,:))), MaxPeak(i,~isnan(MaxPeak(i,:)))./-min(MaxPeak(i,:)),30, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
box off     % format plot
ylim([-1 0])
xlim([0 1200])
ylabel('Norm. Resp')
% 
% 
% % create matrix with binary resp (0) or no-resp (1) 
% No_Resp = find(MaxPeak == 0)
% Resp = find(MaxPeak < 0)
% Dist_NR = Dist(No_Resp);
% Dist_R = Dist(Resp);
% 
% subplot(8,1,7)
% hist(Dist_R, 15); ylabel('Freq Resp'); ylim([0 20])
% subplot(8,1,8)
% hist(Dist_NR, 15); ylabel('Freq No Resp'); ylim([0 10])
% xlabel('Distance from Soma (microns)')
% for i = 7:8
%     subplot(8,1,i)
%     box off
%     xlim([0 1200])
% end


%% REVERSAL POTENTIAL ANALYSIS


figure
subplot(6,1,1)
for i = 1:2
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:))),30, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,2)
for i = 3:7
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:))),30, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,3)
for i = 8:13
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:))),30, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,4)
for i = 14:18
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:))),30, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
subplot(6,1,5)
for i = 19:22
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:))),30, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 1:5         %format all plots
    subplot(6,1,i)
    box off
    ylim([-100 -50])
    xlim([0 1200])
    ylabel('E_r_e_v (mV)')
end

% everything, normalized to max response within neuron 
subplot(6,1,6)
for i = 1:2
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:)))./nanmean(Erev(i,:)),30, c(3,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 3:7
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:)))./nanmean(Erev(i,:)),30, c(20,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 8:13
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:)))./nanmean(Erev(i,:)),30, c(30,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 14:18
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:)))./nanmean(Erev(i,:)),30, c(45,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
for i = 19:22
    scatter(Dist(i,~isnan(Erev(i,:))), Erev(i,~isnan(Erev(i,:)))./nanmean(Erev(i,:)),30, c(60,:), 'filled','MarkerEdgeColor', 'k', 'LineWidth',1.5); hold on
end
box off     % format plot
ylim([0.8 1.2])
xlim([0 1200])
ylabel('Norm. E_r_e_v')
plot([0 1200], [0.95 0.95], 'k-', 'LineWidth', 1)
plot([0 1200], [1.05 1.05], 'k-', 'LineWidth', 1)
subplot(6,1,1)
title('GM Apparent Reversal Potentials')









