% Analysis on 7/10/17    

%% Branch 1, 5 positions %%%%%%%%%%%%%%

% Branch 1 Traces: individual responses, centripetal, centrifugal summation
[traces_11, laser_traces_11, laser_ind_11, Vm_11, laser_11, time_11] = browse_responses_v4('AGO_009__0011.abf', -80, -30, 'individual');
[traces_10s, laser_traces_10s, laser_ind_10s, Vm_10s, laser_10s, time_10s] = browse_summation_v4('AGO_009__0010.abf', -80, -30, 'Centripetal', 5);
[traces_11s, laser_traces_11s, laser_ind_11s, Vm_11s, laser_11s, time_11s] = browse_summation_v4('AGO_009__0011.abf', -80, -30, 'Centrifugal', 5);

% MEAN TRACES AND CALCULATIONS
k = 1;
num_pulses = 5;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses]% k+3*num_pulses k+4*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_11(:,i), std_trace_11(:,i), mn_peak_11(i), std_peak_11(i), mn_int_11(i), std_int_11(i)] = mean_responses_v2(traces_11, stim_ind_vect, 12000);
    k = k+1;
end
% mean summation responses
[mn_trace_10s, std_trace_10s, mn_peak_10s, std_peak_10s, mn_int_10s, std_int_10s] = mean_summation(traces_10s, 40000); % avg-ed 17 18 19 20
[mn_trace_11s, std_trace_11s, mn_peak_11s, std_peak_11s, mn_int_11s, std_int_11s] = mean_summation(traces_11s, 40000);% only avg-ed 15 16 17
% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_cp_mat = ones(40000, num_pulses).*-40;
predict_cf_mat = ones(40000, num_pulses).*-40;
t_end = 12000;
k = 0;
for i = 1:num_pulses
    predict_cf_mat(1+k*offset:t_end+k*offset, i) = mn_trace_11(:,i);
    k = k+1;
end
linear_cf_sum_B1 =  (predict_cf_mat(:,1)+predict_cf_mat(:,2)+ predict_cf_mat(:,3)+predict_cf_mat(:,4)+ predict_cf_mat(:,5)) - (-40*(num_pulses-1));
linear_cf_peak_B1 = min(linear_cf_sum_B1)- -40;

k = 0
for i = [5 4 3 2 1]
    predict_cp_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_11(:,i);
    k = k+1;
end
linear_cp_sum_B1 =  (predict_cp_mat(:,1)+predict_cp_mat(:,2)+ predict_cp_mat(:,3)+predict_cp_mat(:,4)+ predict_cp_mat(:,5))-(-40*(num_pulses-1));
linear_cp_peak_B1 = min(linear_cp_sum_B1)- -40;

%% Plotting Traces

figure
subplot(2,1,1)
plot(mn_trace_10s); hold on; plot(mn_trace_11s); title('Real Branch 1'); ylabel('mV')
legend('Centripetal', 'Centrifugal')
subplot(2,1,2); plot(linear_cp_sum_B1); hold on; plot(linear_cf_sum_B1);  title('Expected Branch 1'); ylabel('mV')
for i = 1:2
subplot(2,1,i)
box off
ylim([-45 -38])
xlim([0 3e4])
end

% compare peaks of CP and CF directions for each branch:
real_cp_vect = [mn_peak_10s];
real_cf_vect = [mn_peak_11s];
figure
plot(real_cp_vect, real_cf_vect, 'ro'); hold on; box off
plot([-10 0], [-10 0], 'k-')
ylabel('Centrifugal (mV)')
xlabel('Centripetal (mV)')


% compare peaks of real and linear summation traces
% vectors are arranged in [B1 B2 B3] order:
linear_cp_vect = [linear_cp_peak_B1] ;
linear_cf_vect = [linear_cf_peak_B1]; 
figure
plot(linear_cp_vect, real_cp_vect,  'ro'); hold on; box off
plot(linear_cf_vect, real_cf_vect, 'bo')
plot([-10 0], [-10 0], 'k-')
ylabel('Real (mV)')
xlabel('Expected (mV)')
             