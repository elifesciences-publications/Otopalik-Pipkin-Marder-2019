% Analysis on 7/10/17    

%% Branch 1, 9 positions %%%%%%%%%%%%%%

% Branch 1 Traces: individual responses, centripetal, centrifugal summation
[traces_8, laser_traces_8, laser_ind_8, Vm_8, laser_8, time_8] = browse_responses_v4('AGO_021_0008.abf', -80, -30, 'individual');
[traces_12, laser_traces_12, laser_ind_12, Vm_12, laser_12, time_12] = browse_summation_v4('AGO_021_0012.abf', -80, -30, 'Centripetal', 9);
[traces_13, laser_traces_13, laser_ind_13, Vm_13, laser_13, time_13] = browse_summation_v4('AGO_021_0013.abf', -80, -30, 'Centrifugal', 9);

% MEAN TRACES AND CALCULATIONS
k = 1;
num_pulses = 9;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_8(:,i), std_trace_8(:,i), mn_peak_8(i), std_peak_8(i), mn_int_8(i), std_int_8(i)] = mean_responses_v2(traces_8, stim_ind_vect, 15000);
    k = k+1;
end
% mean summation responses
[mn_trace_12, std_trace_12, mn_peak_12, std_peak_12, mn_int_12, std_int_12] = mean_summation(traces_12, 40000);
[mn_trace_13, std_trace_13, mn_peak_13, std_peak_13, mn_int_13, std_int_13] = mean_summation(traces_13, 40000);

% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_cp_mat = ones(40000, num_pulses).*-40;
predict_cf_mat = ones(40000, num_pulses).*-40;
t_end = 15000;
k = 0;
for i = 1:num_pulses
    predict_cp_mat(1+k*offset:t_end+k*offset, i) = mn_trace_8(:,i);
    k = k+1;
end
linear_cp_sum_B1 =  (predict_cp_mat(:,1)+predict_cp_mat(:,2)+ predict_cp_mat(:,3)+predict_cp_mat(:,4)+ predict_cp_mat(:,5)+predict_cp_mat(:,6)+predict_cp_mat(:,7)+predict_cp_mat(:,8)+predict_cp_mat(:,9)) - (-40*(num_pulses-1));
linear_cp_peak_B1 = min(linear_cp_sum_B1)- -40;

k = 0
for i = [9 8 7 6 5 4 3 2 1]
    predict_cf_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_8(:,i);
    k = k+1;
end
linear_cf_sum_B1 =  (predict_cf_mat(:,1)+predict_cf_mat(:,2)+ predict_cf_mat(:,3)+predict_cf_mat(:,4)+ predict_cf_mat(:,5)+predict_cf_mat(:,6)+predict_cf_mat(:,7)+predict_cf_mat(:,8)+predict_cf_mat(:,9))-(-40*(num_pulses-1));
linear_cf_peak_B1 = min(linear_cf_sum_B1)- -40;

%% Branch 2, 9 positions %%%%%%%%%%%%%%%%%

% Branch 2 Traces: individual responses, centripetal, centrifugal summation
[traces_9, laser_traces_9, laser_ind_9, Vm_9, laser_9, time_9] = browse_responses_v4('AGO_021_0009.abf', -80, -30, 'individual');
[traces_10, laser_traces_10, laser_ind_10, Vm_10, laser_10, time_10] = browse_summation_v4('AGO_021_0010.abf', -80, -30, 'Centripetal', 12);
[traces_11, laser_traces_11, laser_ind_11, Vm_11, laser_11, time_11] = browse_summation_v4('AGO_021_0011.abf', -80, -30, 'Centrifugal', 12);

% MEAN TRACES AND CALCULATIONS
k = 1;
num_pulses = 12;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses k+3*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_9(:,i), std_trace_9(:,i), mn_peak_9(i), std_peak_9(i), mn_int_9(i), std_int_9(i)] = mean_responses_v2(traces_9, stim_ind_vect, 15000);
    k = k+1;
end
% mean summation responses
[mn_trace_10, std_trace_10, mn_peak_10, std_peak_10, mn_int_10, std_int_10] = mean_summation(traces_10, 40000);
[mn_trace_11, std_trace_11, mn_peak_11, std_peak_11, mn_int_11, std_int_11] = mean_summation(traces_11, 40000);


% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_cp_mat = ones(40000, num_pulses).*-40;
predict_cf_mat = ones(40000, num_pulses).*-40;
t_end = 15000;
k = 0;
for i = 1:num_pulses
    predict_cp_mat(1+k*offset:t_end+k*offset, i) = mn_trace_9(:,i);
    k = k+1;
end
linear_cp_sum_B2 =  (predict_cp_mat(:,1)+predict_cp_mat(:,2)+ predict_cp_mat(:,3)+predict_cp_mat(:,4)+ predict_cp_mat(:,5)+predict_cp_mat(:,6)+predict_cp_mat(:,7)+predict_cp_mat(:,8)+predict_cp_mat(:,9)+predict_cp_mat(:,10)+predict_cp_mat(:,11)+predict_cp_mat(:,12))- (-40*(num_pulses-1));
linear_cp_peak_B2 = min(linear_cp_sum_B2)- -40; 

k = 0
for i = [12 11 10 9 8 7 6 5 4 3 2 1]
    predict_cf_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_9(:,i);
    k = k+1;
end
linear_cf_sum_B2 =  (predict_cf_mat(:,1)+predict_cf_mat(:,2)+ predict_cf_mat(:,3)+predict_cf_mat(:,4)+ predict_cf_mat(:,5)+predict_cf_mat(:,6)+predict_cf_mat(:,7)+predict_cf_mat(:,8)+predict_cf_mat(:,9)+predict_cf_mat(:,10)+predict_cf_mat(:,11)+predict_cf_mat(:,12))- (-40*(num_pulses-1));
linear_cf_peak_B2 = min(linear_cf_sum_B2)- -40;

%% Branch 3, 10 positions %%%%%%%%%%%%%%%%%

% Branch 3 Traces:  individual responses, centripetal, centrifugal summation
[traces_14, laser_traces_14, laser_ind_14, Vm_14, laser_14, time_14] = browse_responses_v4('AGO_021_0014.abf', -80, -30, 'individual');
[traces_15, laser_traces_15, laser_ind_15, Vm_15, laser_15, time_15] = browse_summation_v4('AGO_021_0015.abf', -80, -30, 'Centripetal', 10);
[traces_16, laser_traces_16, laser_ind_16, Vm_16, laser_16, time_16] = browse_summation_v4('AGO_021_0016.abf', -80, -30, 'Centrifugal', 10);

% MEAN TRACES AND CALCULATIONS
k = 1;
num_pulses = 10;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_14(:,i), std_trace_14(:,i), mn_peak_14(i), std_peak_14(i), mn_int_14(i), std_int_14(i)] = mean_responses_v2(traces_14, stim_ind_vect, 15000);
    k = k+1;
end
% mean summation responses
[mn_trace_15, std_trace_15, mn_peak_15, std_peak_15, mn_int_15, std_int_15] = mean_summation(traces_15, 40000);
[mn_trace_16, std_trace_16, mn_peak_16, std_peak_16, mn_int_16, std_int_16] = mean_summation(traces_16, 50000);

% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_cp_mat = ones(40000, num_pulses).*-40;
predict_cf_mat = ones(40000, num_pulses).*-40;
t_end = 15000;
k = 0;
for i = 1:num_pulses
    predict_cp_mat(1+k*offset:t_end+k*offset, i) = mn_trace_14(:,i);
    k = k+1;
end
linear_cp_sum_B3 =  (predict_cp_mat(:,1)+predict_cp_mat(:,2)+ predict_cp_mat(:,3)+predict_cp_mat(:,4)+ predict_cp_mat(:,5)+predict_cp_mat(:,6)+predict_cp_mat(:,7)+predict_cp_mat(:,8)+predict_cp_mat(:,9)+predict_cp_mat(:,10))- (-40*(num_pulses-1));
linear_cp_peak_B3 = min(linear_cp_sum_B3)- -40;

k = 0
for i = [10 9 8 7 6 5 4 3 2 1]
    predict_cf_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_14(:,i);
    k = k+1;
end
linear_cf_sum_B3 =  (predict_cf_mat(:,1)+predict_cf_mat(:,2)+ predict_cf_mat(:,3)+predict_cf_mat(:,4)+ predict_cf_mat(:,5)+predict_cf_mat(:,6)+predict_cf_mat(:,7)+predict_cf_mat(:,8)+predict_cf_mat(:,9)+predict_cf_mat(:,10))- (-40*(num_pulses-1));
linear_cf_peak_B3 = min(linear_cf_sum_B3)- -40;
%% Plotting Traces

figure
subplot(1,3,1); plot(mn_trace_12); hold on; plot(mn_trace_13); title('Branch 1'); ylabel('mV')
subplot(1,3,2); plot(mn_trace_10); hold on; plot(mn_trace_11); title('Branch 2')
subplot(1,3,3); plot(mn_trace_15); hold on; plot(mn_trace_16); title('Branch 3')
legend('Centripetal', 'Centrifugal')
for i = 1:3
subplot(1,3,i)
box off
ylim([-46 -38])
xlim([0 4e4])
end

figure
subplot(1,3,1); plot(linear_cp_sum_B1); hold on; plot(linear_cf_sum_B1);  title('Branch 1'); ylabel('mV')
subplot(1,3,2); plot(linear_cp_sum_B2); hold on; plot(linear_cf_sum_B2); title('Branch 2')
subplot(1,3,3); plot(linear_cp_sum_B3); hold on; plot(linear_cf_sum_B3); title('Branch 3')
legend('Centripetal', 'Centrifugal')
for i = 1:3
subplot(1,3,i)
box off
ylim([-46 -38])
xlim([0 4e4])
end

% compare peaks of CP and CF directions for each branch:
real_cp_vect = [mn_peak_12 mn_peak_10 mn_peak_15];
real_cf_vect = [mn_peak_13 mn_peak_11 mn_peak_16];
figure
plot(real_cp_vect, real_cf_vect, 'ro'); hold on; box off
plot([-6 0], [-6 0], 'k-')
ylabel('Centrifugal (mV)')
xlabel('Centripetal (mV)')


% compare peaks of real and linear summation traces
% vectors are arranged in [B1 B2 B3] order:
linear_cp_vect = [linear_cp_peak_B1 linear_cp_peak_B2 linear_cp_peak_B3] ;
linear_cf_vect = [linear_cf_peak_B1 linear_cf_peak_B2 linear_cf_peak_B3]; 
figure
plot(linear_cp_vect, real_cp_vect,  'ro'); hold on; box off
plot(linear_cf_vect, real_cf_vect, 'bo')
plot([-6 0], [-6 0], 'k-')
ylabel('Real (mV)')
xlabel('Expected (mV)')

%% Neurite Tree, 11 positions, 2 orders %%% %%%%%%%%%%%

num_pulses = 11
% Branch 1 Traces: individual responses, centripetal, centrifugal summation
[traces_17, laser_traces_17, laser_ind_17, Vm_17, laser_17, time_17] = browse_responses_v4('AGO_021_0017.abf', -80, -30, 'individual');
[traces_18, laser_traces_18, laser_ind_18, Vm_18, laser_18, time_18] = browse_summation_v4('AGO_021_0018.abf', -80, -30, 'Order 1', num_pulses);
[traces_19, laser_traces_19, laser_ind_19, Vm_19, laser_19, time_19] = browse_summation_v4('AGO_021_0019.abf', -80, -30, 'Order 2', num_pulses);

% MEAN TRACES AND CALCULATIONS
k = 1;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_17(:,i), std_trace_17(:,i), mn_peak_17(i), std_peak_17(i), mn_int_17(i), std_int_17(i)] = mean_responses_v2(traces_17, stim_ind_vect, 15000);
    k = k+1;
end
% mean summation responses
[mn_trace_18, std_trace_18, mn_peak_18, std_peak_18, mn_int_18, std_int_18] = mean_summation(traces_18, 50000); % ORDER 1 avg-ed [2 3]
[mn_trace_19, std_trace_19, mn_peak_19, std_peak_19, mn_int_19, std_int_19] = mean_summation(traces_19, 50000); % ORDER 2



% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_O1_mat = ones(60000, num_pulses).*-40;
predict_O2_mat = ones(60000, num_pulses).*-40;


t_end = 15000;
% Order 1 (O1)
k = 0;
for i = 1:num_pulses
    predict_O1_mat(1+k*offset:t_end+k*offset, i) = mn_trace_17(:,i);
    k = k+1;
end
linear_O1_sum =  (predict_O1_mat(:,1)+predict_O1_mat(:,2)+ predict_O1_mat(:,3)+predict_O1_mat(:,4)+ predict_O1_mat(:,5)+ predict_O1_mat(:,6)+ predict_O1_mat(:,7)+ predict_O1_mat(:,8)+ predict_O1_mat(:,9)+ predict_O1_mat(:,10)+ predict_O1_mat(:,11)) - (-40*(num_pulses-1));
linear_O1_peak = min(linear_O1_sum)- -40;

% Order 2(O2) 
k = 0
for i = [11 10 9 8 7 6 5 4 3 2 1]
    predict_O2_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_17(:,i);
    k = k+1;
end
linear_O2_sum =  (predict_O2_mat(:,1)+predict_O2_mat(:,2)+ predict_O2_mat(:,3)+predict_O2_mat(:,4)+ predict_O2_mat(:,5)+predict_O2_mat(:,6)+ predict_O2_mat(:,7)+ predict_O2_mat(:,8)+ predict_O2_mat(:,9)+ predict_O2_mat(:,10)+ predict_O2_mat(:,11))-(-40*(num_pulses-1));
linear_O2_peak = min(linear_O2_sum)- -40;

%% Plotting Traces for Neurite Tree

% plot avg traces of temporal summation (3 orders) 
figure
%plot real sums
subplot(3,2,1); plot(mn_trace_18); ylabel('mV'); title('Order 1')
subplot(3,2,2); plot(mn_trace_19); title('Order 2')
%plot linear sums
subplot(3,2,3); plot(linear_O1_sum); ylabel('mV')
subplot(3,2,4); plot(linear_O2_sum)
%plot both, same axes
subplot(3,2,5); plot(mn_trace_18); hold on; plot(linear_O1_sum); ylabel('mV'); xlabel('Time (s)')
subplot(3,2,6); plot(mn_trace_19); hold on; plot(linear_O2_sum);  xlabel('Time (s)')

for i = 1:6
subplot(3,2,i)
box off
ylim([-45 -39])
xlim([0 3.5e4])
end

%Scatter Plots
% compare peaks of real and linear summation traces
real_tree_vect = [mn_peak_18 mn_peak_19]; % [O1 O2 O3 O4 O5]
linear_tree_vect = [linear_O1_peak linear_O2_peak] ;
figure
plot(linear_tree_vect, real_tree_vect,  'ro'); hold on; box off
plot([-6 0], [-6 0], 'k-')
ylabel('Real (mV)') 
xlabel('Expected (mV)')

             
             