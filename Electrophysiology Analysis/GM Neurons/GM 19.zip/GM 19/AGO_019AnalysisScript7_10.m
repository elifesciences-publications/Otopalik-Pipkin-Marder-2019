% Analysis on 7/10/17    

%% Branch 1, 12 positions %%%%%%%%%%%%%%

% Branch 1 Traces: individual responses, centripetal, centrifugal summation
[traces_7, laser_traces_7, laser_ind_7, Vm_7, laser_7, time_7] = browse_responses_v4('AGO_019_0007.abf', -80, -30, 'individual');
[traces_8, laser_traces_8, laser_ind_8, Vm_8, laser_8, time_8] = browse_summation_v4('AGO_019_0008.abf', -80, -30, 'Centrifugal', 12);
[traces_9, laser_traces_9, laser_ind_9, Vm_9, laser_9, time_9] = browse_summation_v4('AGO_019_0009.abf', -80, -30, 'Centripetal', 12);

% MEAN TRACES AND CALCULATIONS
k = 1;
num_pulses = 12;
for i = 1:num_pulses % mean individual responses
    stim_ind_vect = [k k+num_pulses k+2*num_pulses k+3*num_pulses k+4*num_pulses] %k+2*num_pulses k+3*num_pulses];
    [mn_trace_7(:,i), std_trace_7(:,i), mn_peak_7(i), std_peak_7(i), mn_int_7(i), std_int_7(i)] = mean_responses_v2(traces_7, stim_ind_vect, 15000);
    k = k+1;
end
% mean summation responses
[mn_trace_8, std_trace_8, mn_peak_8, std_peak_8, mn_int_8, std_int_8] = mean_summation(traces_8, 40000); 
[mn_trace_9, std_trace_9, mn_peak_9, std_peak_9, mn_int_9, std_int_9] = mean_summation(traces_9, 40000);% only avg-ed 1 3 5 7

% Predicted Linear Summation @ 5 Hz of individual responses
% cp = centripetal; cf = centrifugal
offset = 2000; %if pulses are at 5 Hz
predict_cp_mat = ones(40000, num_pulses).*-40;
predict_cf_mat = ones(40000, num_pulses).*-40;
t_end = 12000;
k = 0;
for i = 1:num_pulses
    predict_cp_mat(1+k*offset:t_end+k*offset, i) = mn_trace_7(:,i);
    k = k+1;
end
linear_cp_sum_B1 =  (predict_cp_mat(:,1)+predict_cp_mat(:,2)+ predict_cp_mat(:,3)+predict_cp_mat(:,4)+ predict_cp_mat(:,5)+predict_cp_mat(:,6)+predict_cp_mat(:,7)+predict_cp_mat(:,8)+predict_cp_mat(:,9)+predict_cp_mat(:,10)+predict_cp_mat(:,11)+predict_cp_mat(:,12)) - (-40*(num_pulses-1));
linear_cp_peak_B1 = min(linear_cp_sum_B1)- -40;

k = 0
for i = [12 11 10 9 8 7 6 5 4 3 2 1]
    predict_cf_mat(1+k*offset:t_end+k*offset, k+1) = mn_trace_7(:,i);
    k = k+1;
end
linear_cf_sum_B1 =  (predict_cf_mat(:,1)+predict_cf_mat(:,2)+ predict_cf_mat(:,3)+predict_cf_mat(:,4)+ predict_cf_mat(:,5)+predict_cf_mat(:,6)+predict_cf_mat(:,7)+predict_cf_mat(:,8)+predict_cf_mat(:,9)+predict_cf_mat(:,10)+predict_cf_mat(:,11)+predict_cf_mat(:,12))-(-40*(num_pulses-1));
linear_cf_peak_B1 = min(linear_cf_sum_B1)- -40;

%% Plotting Traces

figure
subplot(2,1,1)
plot(mn_trace_9); hold on; plot(mn_trace_8); title('Real Branch 1'); ylabel('mV')
legend('Centripetal', 'Centrifugal')
subplot(2,1,2); plot(linear_cp_sum_B1); hold on; plot(linear_cf_sum_B1);  title('Expected Branch 1'); ylabel('mV')
for i = 1:2
subplot(2,1,i)
box off
ylim([-50 -38])
xlim([0 4e4])
end

% compare peaks of CP and CF directions for each branch:
real_cp_vect = [mn_peak_9];
real_cf_vect = [mn_peak_8];
figure
plot(real_cp_vect, real_cf_vect, 'ro'); hold on; box off
plot([-10 0], [-10 0], 'k-')
ylabel('Centrifugal (mV)')
xlabel('Centripetal (mV)')


% compare peaks of real and linear summation traces
% vectors are arranged in [B1 B2 B3] order:
linear_cp_vect = [linear_cp_peak_B1] ;
linear_cf_vect = [linear_cf_peak_B1]; 
figure
plot(linear_cp_vect, real_cp_vect,  'ro'); hold on; box off
plot(linear_cf_vect, real_cf_vect, 'bo')
plot([-10 0], [-10 0], 'k-')
ylabel('Real (mV)')
xlabel('Expected (mV)')
             